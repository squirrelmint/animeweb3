<?php

class UnnamespacedClass
{
}
